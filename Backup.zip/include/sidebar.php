<?php require_once('./config/functions.php'); ?>

 <!-- ========== Left Sidebar Start ========== -->
            <div class="left side-menu">
                <div class="sidebar-inner slimscrollleft">

                    <!--- Sidemenu -->
                    <div id="sidebar-menu">
                        <ul>
                           <li class="menu-title">Navigation</li>

                           <!--  <li class="">
                                <a href="dashboard.php" class="waves-effect"><i class="mdi mdi-view-dashboard"></i><span class="label label-success pull-right">2</span> <span> Dashboard </span> </a>
                                <ul class="list-unstyled">
                                    <li><a href="index.html">Menu1</a></li>
                                    <li><a href="#">Menu2</a></li>
                                </ul>
                            </li> -->

                             
                            
                            <?php if(isset($_SESSION['scl']) && $_SESSION['scl']['user_type'] == '1'){ ?>
                             <li class="">
                                <a href="dashboard.php" class="waves-effect"><i class="mdi mdi-view-dashboard"></i> <span> Dashboard </span> </a>
                            </li>

                            <li class="">
                                <a href="schools.php" class="waves-effect"><i class="mdi mdi-school"></i> <span> Schools </span> </a>
                            </li>
                            <li class="">
                                <a href="enrollments.php" class="waves-effect"><i class="mdi mdi-book-multiple"></i> <span> Enrollments </span> </a>
                            </li>
                            <li class="">
                                <a href="fee_report.php" class="waves-effect"><i class="mdi mdi-currency-inr"></i> <span> Fee Report </span> </a>
                            </li>
                            <?php } ?>

                            <?php if(isset($_SESSION['scl']) && $_SESSION['scl']['user_type'] == '2'){ ?>
                             <li class="">
                                <a href="dashboard.php" class="waves-effect"><i class="mdi mdi-view-dashboard"></i> <span> Dashboard </span> </a>
                            </li>

                            <li class="">
                                <a href="students.php" class="waves-effect"><i class="mdi mdi-account-card-details"></i> <span> Students </span> </a>
                            </li>

                            <li class="">
                                <a href="fee.php" class="waves-effect"><i class="mdi mdi-credit-card"></i> <span> Pay Fee </span> </a>
                            </li>

                            <!-- <li class="">
                                <a href="fee_report.php" class="waves-effect"><i class="mdi mdi-view-dashboard"></i> <span> Fee Report </span> </a>
                            </li> -->

                            <?php } ?>

                            

                        </ul>
                    </div>
                    <!-- Sidebar -->
                    <div class="clearfix"></div>

                   

                </div>
                <!-- Sidebar -left -->

            </div>
            <!-- Left Sidebar End -->