<?php
	
	if(!isset($_SESSION['scl']) || count($_SESSION['scl']) == 0){
		header('location:index.php');
	}

?>