<?php
	
	session_start();
	unset($_SESSION['scl']);
	header('location:index.php');

?>