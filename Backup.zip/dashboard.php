<?php require_once('config/functions.php'); ?>
<?php require_once('config/session.php'); ?>

<?php 
    
    $total_schools = count(getAll('schools'));
    
    if($_SESSION['scl']['user_type'] == 2){
        $total_fees = "SELECT SUM(amount) as total_fees FROM fee WHERE school_id = '".$_SESSION['scl']['user_id']."' ";
    }else{
        $total_fees = "SELECT SUM(amount) as total_fees FROM fee";
    }   

    $total_fees = getRaw($total_fees);
    $total_fees = $total_fees[0]['total_fees'];

    if($_SESSION['scl']['user_type'] == 2){
        $total_students_enrolled_today = "SELECT COUNT(*) as total_students_enrolled_today FROM `students` WHERE DATE(`created_at`) = CURDATE() AND school_id = '".$_SESSION['scl']['user_id']."' ";
    }else{
        $total_students_enrolled_today = "SELECT COUNT(*) as total_students_enrolled_today FROM `students` WHERE DATE(`created_at`) = CURDATE()";
    }   
        
    $total_students_enrolled_today = getRaw($total_students_enrolled_today);
    $total_students_enrolled_today = $total_students_enrolled_today[0]['total_students_enrolled_today'];
    
    if($_SESSION['scl']['user_type'] == 2){
        $total_today_collection = "SELECT COALESCE(SUM(amount),0) as total_today_collection FROM `fee` WHERE DATE(`created_at`) = CURDATE() AND school_id = '".$_SESSION['scl']['user_id']."'";
    }else{
        $total_today_collection = "SELECT COALESCE(SUM(amount),0) as total_today_collection FROM `fee` WHERE DATE(`created_at`) = CURDATE() ";
    } 
    $total_today_collection = getRaw($total_today_collection);
    $total_today_collection = $total_today_collection[0]['total_today_collection'];

    
    if($_SESSION['scl']['user_type'] == 2){
        $total_students = count(getWhere('students','school_id',$_SESSION['scl']['user_id']));
    }else{
        $total_students = count(getAll('students'));
    }
    
?>
<!DOCTYPE html>
<html>
<?php require_once('include/headerscript.php'); ?>
<body class="fixed-left">
        <!-- Begin page -->
        <div id="wrapper">

            <!-- Top Bar Start -->
            <?php require_once('include/topbar.php'); ?>
            <!-- Top Bar End -->

            <!-- ========== Left Sidebar Start ========== -->
            <?php require_once('include/sidebar.php'); ?>
            <!-- Left Sidebar End -->



            <!-- ============================================================== -->
            <!-- Start right Content here -->
            <!-- ============================================================== -->
            <div class="content-page">
                <!-- Start content -->
                <div class="content">
                    <div class="container">
        <!--                 <div class="row">
							<div class="col-xs-12">
								<div class="page-title-box">
                                    <h4 class="page-title">Dashboard</h4>
                                    <ol class="breadcrumb p-0 m-0">
                                        <li>
                                            <a href="#">Zircos</a>
                                        </li>
                                        <li>
                                            <a href="#">Dashboard</a>
                                        </li>
                                        <li class="active">
                                            Dashboard
                                        </li>
                                    </ol>
                                    <div class="clearfix"></div>
                                </div>
							</div>
						</div> -->
                        <!-- end row -->

                        <div class="row" style="margin-top: 50px;">

                            <!-- <div class="col-lg-1"></div> -->

                            <?php if($_SESSION['scl']['user_type'] == 1){ ?>
    
                            <div class="col-lg-3 col-md-4 col-sm-6">
                                <div class="card-box widget-box-one">
                                    <i class="mdi mdi-chart-areaspline widget-one-icon"></i>
                                    <div class="wigdet-one-content">
                                        <p class="m-0 text-uppercase font-600 font-secondary text-overflow text-center" title="Statistics">Total Schools</p>
                                        <h2 class="text-center"><?php echo number_format($total_schools,0);  ?></h2>
                                    </div>
                                </div>
                            </div>

                            <?php } ?>

                            <div class="col-lg-3 col-md-4 col-sm-6">
                                <div class="card-box widget-box-one">
                                    <i class="mdi mdi-chart-areaspline widget-one-icon"></i>
                                    <div class="wigdet-one-content">
                                        <p class="m-0 text-uppercase font-600 font-secondary text-overflow text-center" title="Statistics">Total Enrollment</p>
                                        <h2 class="text-center"><?php echo number_format($total_students,0);  ?></h2>
                                    </div>
                                </div>
                            </div>

                            <div class="col-lg-3 col-md-4 col-sm-6">
                                <div class="card-box widget-box-one">
                                    <i class="mdi mdi-chart-areaspline widget-one-icon"></i>
                                    <div class="wigdet-one-content">
                                        <p class="m-0 text-uppercase font-600 font-secondary text-overflow text-center" title="Statistics">Today's Enrollment</p>
                                        <h2 class="text-center"><?php echo number_format($total_students_enrolled_today,0);  ?></h2>
                                    </div>
                                </div>
                            </div>

                            <div class="col-lg-3 col-md-4 col-sm-6">
                                <div class="card-box widget-box-one">
                                    <i class="mdi mdi-chart-areaspline widget-one-icon"></i>
                                    <div class="wigdet-one-content">
                                        <p class="m-0 text-uppercase font-600 font-secondary text-overflow text-center" title="Statistics">Total Fees</p>
                                        <h2 class="text-center"><?php echo number_format($total_fees,2);  ?></h2>
                                    </div>
                                </div>
                            </div>

                            <div class="col-lg-3 col-md-4 col-sm-6">
                                <div class="card-box widget-box-one">
                                    <i class="mdi mdi-chart-areaspline widget-one-icon"></i>
                                    <div class="wigdet-one-content">
                                        <p class="m-0 text-uppercase font-600 font-secondary text-overflow text-center" title="Statistics">Today's Fee Collection</p>
                                        <h2 class="text-center"><?php echo number_format($total_today_collection,2);  ?></h2>
                                    </div>
                                </div>
                            </div>

                            

                        </div>
                        <!-- end row -->


                    </div> <!-- container -->
                </div> <!-- content -->
            </div>


            <!-- ============================================================== -->
            <!-- End Right content here -->
            <!-- ============================================================== -->


           

        </div>
        <!-- END wrapper -->
        <!-- START Footerscript -->
        <?php require_once('include/footerscript.php'); ?>

    </body>
</html>
